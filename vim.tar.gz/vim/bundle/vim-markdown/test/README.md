You can run the tests using the Makefile from the top directory:

    make test

To run them manually please refer to the instructions/commands in the Makefile.
